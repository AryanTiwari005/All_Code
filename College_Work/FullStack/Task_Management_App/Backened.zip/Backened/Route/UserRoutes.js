
import express from 'express';
import {User} from '../controllers/User.controller.js'; 
const router = express.Router();



 
router.post('/api/User',User);