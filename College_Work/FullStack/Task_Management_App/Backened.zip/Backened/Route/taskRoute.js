
import {getTask,addTask,deleteTask} from '../controllers/task.controllers.js';
import express from 'express';

const router = express.Router();

 router.get('/',getTask);
 router.post('/',addTask);
 router.delete('/:id',deleteTask);


export default router;