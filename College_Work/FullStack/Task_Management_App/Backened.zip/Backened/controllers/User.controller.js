import bcryptjs from "bcryptjs";
import User from "../model/UserSchema.js";
import asyncHandler from "../utils/asynchandler.js";

export const registerUser = asyncHandler(async (req, res) => {

        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return res.status(400).json({
                message: "Please fill all credentials"
            });
        }

        const existingUser = await User.findOne({ email });

        if (!existingUser) {
            return res.status(409).json({
                message: "user not  registered"
            });
        }

        const hashedPassword = await bcryptjs.hash(password, 10);

        const newUser = await User.create({
            username,
            email,
            password: hashedPassword
        });

        res.status(201).json({
            message: "User registered successfully",
            user: newUser
        });

});



export const loginUser = asyncHandler(async (req,res)=>{
  
    const {username,email,password} = req.body;

    if(!username || !email || !password){
        return res.status(400).json({
            message:"Please fill all the credentials"
        })
    }
    const existinguser = await User.findOne({email});
    if(existinguser){
      return res.status(400).json({
        message:"User already exists"
      })
    }
    const isPasswordMatched = bcryptjs.compare(password,User.password);
    if(isPasswordMatched){
      return res.status(200).json({
        message:"Login successful",
        user:User
      })
    }else{
      return res.status(401).json({
        message:"Invalid credentials"
      })
    }
    
  
})