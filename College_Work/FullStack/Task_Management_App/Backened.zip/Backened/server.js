import dotenv from 'dotenv';
import express from 'express';
import taskRoute from './Route/taskRoute.js';
import connectDB from './db.js';
import cors from 'cors';
import errorhandler from './middleware/errorhandler.js';
const app = express();

dotenv.config();
connectDB();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(express.json());
app.use('/api/tasks',taskRoute);
app.use('/api/users',userRoute);

app.listen(PORT,()=>{
    console.log(`Server is running on the port ${PORT}`);
})
app.use(errorhandler);