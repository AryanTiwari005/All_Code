import mongoose from 'mongoose';
const taskSchema = new mongoose.Schema({
    title: {
        required: true,
        type: String,
        trim: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user",
        required:true
    }


},{timestamp:true})

const task = mongoose.model('task', taskSchema);
export default task;