import mongoose from "mongoose";

const UserSchema  = new  mongoose.Schema({
    username:{
        required:true,
        type:String,
        trim:true
    },
    email:{
        required:true,
        type:String,
        trim:true
    },
    password:{
        required:true,
        type:String,
        trim:true,
        select:false
    }

},{timestamp:true})

const user = mongoose.model('user',UserSchema);

export default user;